# JARVIS iPhone Web — Safari voice fix

This build is tuned for iPhone Safari/WebKit:

- Separates listening from speaking so microphone recognition is stopped before JARVIS talks.
- Creates a fresh SpeechRecognition instance for each turn.
- Explicitly selects an available English voice, preferring en-GB.
- Warms up speech synthesis from the user's ACTIVATE tap.
- Adds a **TEST JARVIS VOICE** button for a direct user-gesture speech test.
- Shows READY / LISTENING / THINKING / SPEAKING / VOICE ERROR states.

## Update on GitHub Pages
Replace your existing `index.html` with this one. Keep `manifest.webmanifest` and `sw.js` as they are.

## Important iPhone note
Safari/WebKit has known speech-recognition and speech-synthesis edge cases, especially when recognition and audio playback are mixed. If automatic voice output still fails, tap **TEST JARVIS VOICE** once. If that works, JARVIS's voice engine is available and the issue is the Safari recognition/TTS interaction.

For speech recognition, use Safari and make sure Siri is enabled on the iPhone. WebKit documents that Safari's Web Speech recognition uses the same speech engine as Siri.

The OpenAI API key is stored in browser localStorage. This is suitable only for a private prototype; a public deployment should use a server-side proxy.
