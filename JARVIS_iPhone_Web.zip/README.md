# JARVIS — iPhone-only web app

This is a Safari/PWA prototype. It needs to be hosted on HTTPS to behave like a Home Screen web app.

## Easiest phone-only setup

1. Create a GitHub account if you do not already have one.
2. In Safari, create a new public repository, e.g. `jarvis`.
3. Upload `index.html`, `manifest.webmanifest`, and `sw.js`.
4. In the repository, open Settings → Pages.
5. Choose "Deploy from a branch", select the main branch and `/root`, then save.
6. Wait for GitHub Pages to publish the site.
7. Open the published URL in Safari on your iPhone.
8. Tap Share → Add to Home Screen.
9. Open JARVIS from the Home Screen.
10. Tap ACTIVATE and allow microphone access.
11. Say: "Jarvis, what time is it?"

## AI

Open Settings in JARVIS and paste an OpenAI API key. The key is stored in localStorage on this device.

IMPORTANT: This direct-browser API approach is suitable only for a private prototype. Do not publish an API key or use this architecture for a public App Store-quality product. For a real public version, use a small authenticated server as the API proxy.

## Voice limitations

iPhone Safari support for Web Speech recognition can vary by iOS version and browser. The app falls back gracefully if recognition is unavailable. Speech synthesis is provided by the browser.

## Reminders

The prototype handles spoken local commands and AI conversation. Reliable scheduled notifications on iOS web require a proper installed PWA + push-notification implementation and an HTTPS push service; that can be added as the next version.
